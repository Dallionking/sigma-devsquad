
import { ComprehensiveCommunicationHub } from "./ComprehensiveCommunicationHub";

export const ResponsiveUnifiedChatInterface = () => {
  return <ComprehensiveCommunicationHub />;
};
